package com.olanboa.wx.host.activity

import com.olanboa.wx.host.PermissionBaseActivity
import com.olanboa.wx.host.R
import com.olanboa.wx.host.view.loadingview.indicators.SquareSpinIndicator
import kotlinx.android.synthetic.main.spactivity.*

class SpActivity : PermissionBaseActivity() {

    override fun onViewCreated() {


        loadingView.indicator = SquareSpinIndicator()

    }


    override fun setLayoutRes(): Int = R.layout.spactivity

}