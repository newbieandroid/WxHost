package com.olanboa.wx.host.bean

class Test {
}