package com.olanboa.wx.host.view

class MyDialog {
}